"""Outbound rendering worker."""
